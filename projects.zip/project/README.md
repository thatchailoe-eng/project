# Apartment Rental Management System

A full-stack Django 5 + PostgreSQL apartment management system.

## Features
- 🏠 Room/Unit Management (add, edit, filter by status)
- 👤 Tenant Management (profiles, move-in/out dates)
- 📅 Booking & Reservations
- 💰 Rent & Payment Tracking
- 📊 Dashboard with stats and alerts

---

## Setup (Windows)

### 1. Unzip and open the folder
```
cd apartment
```

### 2. Create virtual environment
```
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```

### 3. Create `.env` file
```
copy .env.example .env
```
Edit `.env` and fill in your values. Generate a secret key:
```
python -c "from django.core.management.utils import get_random_secret_key; print(get_random_secret_key())"
```

### 4. Create PostgreSQL database
Open pgAdmin or `psql -U postgres` and run:
```sql
CREATE DATABASE apartment_db;
CREATE USER apartment_user WITH PASSWORD 'yourpassword';
GRANT ALL PRIVILEGES ON DATABASE apartment_db TO apartment_user;
```

### 5. Migrate & create superuser
```
python manage.py migrate
python manage.py createsuperuser
```

### 6. Run
```
python manage.py runserver
```

Visit: http://127.0.0.1:8000

---

## Project Structure
```
apartment/
├── apartment_project/     # Settings, URLs, WSGI
├── apps/
│   ├── rooms/             # Room models, views, templates
│   ├── tenants/           # Tenant models, views, templates
│   ├── bookings/          # Booking models, views, templates
│   ├── payments/          # Payment models, views, templates
│   └── dashboard/         # Dashboard summary view
├── templates/             # Base + login templates
├── static/css/            # CSS styles
├── .env.example
└── requirements.txt
```
